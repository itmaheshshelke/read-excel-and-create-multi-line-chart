package ms.sp2.test.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.assertj.core.api.Assertions.setLenientDateParsing;

import java.io.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.util.IOUtils;
import org.apache.poi.hssf.usermodel.HSSFClientAnchor;
import org.jfree.data.category.DefaultCategoryDataset; 
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.plot.PlotOrientation;
import java.util.Iterator;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import ms.sp2.test.model.Excel;

/**
 * Created by Mahesh Shelke On 29-01-2019.
 */

public class ExcelReader {

	public static List<Excel> excelData(String fileUploadPath) {
		// Creating a Workbook from an Excel file (.xls or .xlsx)
		Workbook workbook = null;
		List<Excel> excelList = new ArrayList<>();
		try {
			workbook = WorkbookFactory.create(new File(fileUploadPath));
			// Getting the Sheet at index zero
			Sheet sheet = workbook.getSheetAt(0);

			// Create a DataFormatter to format and get each cell's value as String
			DataFormatter dataFormatter = new DataFormatter();

			for (Row row : sheet) {
				for (Cell cell : row) {
					String cellValue = dataFormatter.formatCellValue(cell);
					System.out.print(cellValue + "\t");
				}
				System.out.println();
				if (row.getRowNum() != 0) {
					Excel excelObject = new Excel();
					excelObject.setFirstName(row.getCell(0).toString());
					excelObject.setLastName(row.getCell(1).toString());
					excelObject.setEmailId(row.getCell(2).toString());
					excelObject.setContactNo(row.getCell(3).toString());
					excelObject.setGender(row.getCell(4).toString());
					excelObject.setCountry(row.getCell(5).toString());
					excelObject.setPassword(row.getCell(6).toString());
					excelObject.setCreatedBy(1);
					excelObject.setCreatedOn(new Date());
					excelObject.setDelFlag('N');
					excelList.add(excelObject);
				}
			}
		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return excelList;

	}

	public static String readExcelAndCreateBarChart(String filePath) {
		String path="";
		try {
            FileInputStream chart_file_input = new FileInputStream(new File(filePath));
            XSSFWorkbook my_workbook = new XSSFWorkbook(chart_file_input);
            XSSFSheet my_sheet = my_workbook.getSheetAt(0);
            DefaultCategoryDataset my_bar_chart_dataset = new DefaultCategoryDataset();
            Iterator<Row> rowIterator = my_sheet.iterator(); 
            String chart_label="a";
            Number chart_data=0;            
            while(rowIterator.hasNext()) {
                    Row row = rowIterator.next();  
                    Iterator<Cell> cellIterator = row.cellIterator();
                            while(cellIterator.hasNext()) {
                                    Cell cell = cellIterator.next(); 
                                    switch(cell.getCellType()) { 
                                    case Cell.CELL_TYPE_NUMERIC:
                                            chart_data=cell.getNumericCellValue();
                                            break;
                                    case Cell.CELL_TYPE_STRING:
                                            chart_label=cell.getStringCellValue();
                                            break;
                                    }
                            }
            my_bar_chart_dataset.addValue(chart_data.doubleValue(),"Marks",chart_label);
            }               

            JFreeChart BarChartObject=ChartFactory.createBarChart("Subject Vs Marks","Subject","Marks",my_bar_chart_dataset,PlotOrientation.VERTICAL,true,true,false);  
            
            int width=640; /* Width of the chart */
            int height=480; /* Height of the chart */               
            ByteArrayOutputStream chart_out = new ByteArrayOutputStream();          
            ChartUtilities.writeChartAsPNG(chart_out,BarChartObject,width,height);
            int my_picture_id = my_workbook.addPicture(chart_out.toByteArray(), Workbook.PICTURE_TYPE_PNG);
            chart_out.close();
            XSSFDrawing drawing = my_sheet.createDrawingPatriarch();
            ClientAnchor my_anchor = new XSSFClientAnchor();
            my_anchor.setCol1(4);
            my_anchor.setRow1(5);
            XSSFPicture  my_picture = drawing.createPicture(my_anchor, my_picture_id);
            my_picture.resize();
            chart_file_input.close();  
            
            String imagepath=System.getProperty("user.dir")+"/src/main/webapp/resources/rest/upload";

            File file = new File(imagepath);
            if (!file.exists()) {
                if (file.mkdir()) {
                    System.out.println("Directory is created!");
                } else {
                    System.out.println("Failed to create directory!");
                }
            }
             path= file+file.separator+"BarChart.jpeg";
            
            int width1 = 640;    /* Width of the image */
            int height1 = 480;   /* Height of the image */ 
            File BarChart = new File( path ); 
            ChartUtilities.saveChartAsJPEG( BarChart , BarChartObject , width1 , height1 );
            
            
            FileOutputStream out = new FileOutputStream(new File(filePath));
            my_workbook.write(out);
            out.close();            
  
		} catch (Exception e) {
			System.out.println(e);
		}
		return path;
		
	}
	
}
