package ms.sp2.test.constants;
/**
 * Created By:- Mahesh Shelke 
 *
 */
public interface WebAppConstant {

	static String ADD="Record added successfully";
	static String UPDATE="Record updated successfully";
	static String DELETE="Record deleted successFully";
	static String NOTFOUND="Record not found";
	
	static String OK="200";
	static String BADREQUEST="500";
	static String ERROR="404";
}
